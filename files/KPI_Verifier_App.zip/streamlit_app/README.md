# KPI Evidence Verifier — Streamlit + NER

A reference implementation of an on-demand data-assurance tool. Study it, then build
your own — the code is organised and commented so each piece maps to one idea.

## Pages

This is a two-page Streamlit app (one `streamlit run`):

- **Task 2 · KPI Evidence Verifier** (`verifier.py`) — the NER-based, on-demand verifier.
- **Task 1 · KPI Dashboards** (`dashboards.py`) — embeds the Task 1 **Tableau** visualisations.

`app.py` is just the navigation entry that wires the two pages together via `st.navigation`.

### Adding your Tableau dashboards (Task 1 page)

Open `dashboards.py` and edit the `DASHBOARDS` list — paste your Tableau Public view URL
into each `url` field (looks like `https://public.tableau.com/views/<Workbook>/<Dashboard>`).
You can also paste a URL into the "Preview any Tableau link" box on the page to test it live.
Embedding uses Tableau's Embedding API v3, so the view must be public (Tableau Cloud/Server
views work too, for authenticated viewers).

## Run

```bash
pip install -r requirements.txt
python -m spacy download en_core_web_sm   # optional; falls back to rules if absent
python make_evidence.py                   # creates ./evidence/* (already included)
streamlit run app.py
```

## What it does

Each reported line-item starts **unverified**. Pressing **Verify** on a record runs
named-entity recognition over its supporting evidence, extracts the value that matches
the KPI, and reconciles it against the reported number, location, and details — returning
a status (verified / flagged / review / escalate) and a confidence score.

- **Collapsible detail.** Each record's result sits in a "Verification detail" expander you
  can collapse to keep the list tidy.
- **Source-document cross-check.** When a record is flagged (or sent to review/escalate),
  the tool pinpoints the discrepant element in the *actual* source file — it boxes the value
  on the page of a PDF (or the region of an image) and shows the snippet, with a download
  button so you can open and cross-check the original. A "Documents to cross-check" panel at
  the top lists every flagged record's file in one place.
- **Go to the doc (side-by-side).** Each record with a file has a "📄 Go to the doc" button.
  It opens a two-column preview: *what the system found* (reported vs extracted, discrepancy,
  location, decision, and a **Download original** button) on the left, and a full preview of
  the source document on the right — all PDF pages (value boxed), the full image, the
  spreadsheet, or the Word/scanned text — so you can verify side-by-side. "Close preview" hides it.

## Built for real-world evidence (per the technical spec)

The sample set deliberately spans the variety the specification calls out, so each capability
is demonstrable:

- **Document types:** PDF certificates & financial statements, an Excel register, a Word field
  report, transcribed scans, and a photograph of a project **signboard** (infrastructure).
- **KPI/value types:** counts, currency (Indian formatting, e.g. `Rs 4,86,400`), and
  **measurements with units** — including the spec's own example, *Water Holding Capacity
  Increased (kL)*.
- **Languages:** English, **Hindi** (Devanagari numerals), and **Odia** (Odia numerals).
- **Robustness:** lower-quality or unreadable evidence is routed to *review* or *escalate*
  (and the value is never guessed); the spaCy model is augmented with a domain rule + gazetteer
  layer for currency, Indic numerals, and local place names that a generic model won't know.

## How it's built (the four ideas)

1. **NER = pretrained model + domain rules.** spaCy (`en_core_web_sm`) tags the generic
   entities (MONEY, CARDINAL, DATE, GPE, ORG, PERSON). A small rule + gazetteer layer
   adds what the base model can't know: Indian currency (`Rs 4,86,400`), Devanagari
   numerals (`२५०`), and local village names. Domain matches win; spaCy fills the gaps.
   *See `_rule_entities`, `extract_entities`, `SPACY_MAP`.*

2. **Candidate selection.** Not every number is the answer — `pick_candidate` chooses the
   entity whose type matches the KPI (money for revenue, count for beneficiaries) and that
   sits near a cue word like "total / treated / distributed".

3. **Reconcile → confidence → decide.** `verify` compares the candidate to the reported
   value (counts exact, money within 2%), checks the location, then blends extraction
   quality, source reliability, match closeness, and location agreement into one
   confidence score that drives the decision.

4. **On-demand, cached.** Streamlit reruns the whole script on every interaction. Results
   are stored in `st.session_state.results` keyed by record id, so a record is verified
   only when its button is pressed — and stays verified across reruns without recomputing
   everything. The spaCy model loads once via `@st.cache_resource`.

## Make it your own — ideas to extend

- Swap the synthetic `RECORDS` for a real upload (CSV of reported values + a folder of
  evidence files); add a file reader per type (pdfplumber for PDFs, OCR for images).
- Replace/augment the NER with a fine-tuned spaCy pipeline or an LLM extractor behind the
  same `extract_entities` interface.
- Let reviewers accept/override a decision and log it — the start of a human-in-the-loop
  feedback dataset.
- Tune the confidence weights and per-unit tolerances against real reviewer agreement.

No real beneficiary data is used; all evidence is synthetic.
